package com.Transport;

public final class PassByValueRanch {

	public static void main(String args[])
	{
		int x=9;
		int y=x;
		y=10;
		System.out.println("the value of x is "+x);
		System.out.println("the value of y is "+y);
		Cat A = new Cat();
		Cat B=A;
		B.g=100;
		System.out.println("the value of B.g is "+B.g);
		System.out.println("the value of A.g "+A.g);
			
	}
}
class Cat
{
	int g=99;
	
}