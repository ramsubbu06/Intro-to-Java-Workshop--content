package com.Transport;

public class StringExample {
	public static void main(String args[])
	{
		String s = "Hello";
		String s1= s.concat(" World");
	System.out.println(s);
	}

}
