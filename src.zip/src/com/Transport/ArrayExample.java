package com.Transport;

public class ArrayExample {
	public static void main(String args[])
	{
		double[] myList = new double[10];
		double temp=0.0;
		for(int i=0;i<myList.length;i++)
		{
			myList[i]= temp+2.0001;
			temp=myList[i];
		}
		for(double printList:myList)
			System.out.println(printList);
		double dArray[][]={{1,1,1},
						   {1,2,4},
						   {1,3,9}};
				
		                  
		System.out.println(	dArray[2][2]);		
		
	}

}
