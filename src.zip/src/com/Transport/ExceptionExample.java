package com.Transport;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExceptionExample {
	
	public static void main(String args[]) 
	{
		File f = new File("change1.txt");
		FileReader fr;
		try {
			fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			String currentLine;
			while((currentLine=br.readLine())!=null)
			{
				System.out.println(currentLine);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch(Exception e)
		{
			
		}
		catch(Error e)
		{
			
		}
		
		
	}

}
