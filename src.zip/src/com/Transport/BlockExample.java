package com.Transport;

public class BlockExample {
	static
	{
		System.out.println("static block");
	}
	{
		System.out.println("Non-static block");
	}
	public static void main(String args[])
	{
		BlockExample b = new BlockExample();
		System.out.println("main method");
		 
		
	}

}
