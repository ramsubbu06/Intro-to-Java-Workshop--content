package com.Transport;

public class InheritanceExample {

}
class Automobile {
	public String fuel;
public void purpose()
{
	System.out.println("what is the purpose of my life");
}
}
class Truck extends Automobile {
	public static void main(String args[])
	{
		Truck t = new Truck();
		t.fuel="petrol";
		t.purpose();
	}

}