package com.Transport;

public class StaticApple {
	public static int x = 1;

	public static void main(String args[])
	{
		StaticApple a = new StaticApple();
		StaticApple b = new StaticApple();
		System.out.println("--------Static variable--------");
		System.out.println(b.x);//1
		a.x = 5;
		System.out.println(b.x);//5
		StaticApple.x = 10;
		System.out.println(b.x);//10
	}
}
