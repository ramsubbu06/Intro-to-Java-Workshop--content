package com.Transport;

public interface InterfaceExample {
	void methodA();
	public void methodB();
	void methodC();

}
class D implements InterfaceExample
{

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		
	}
	
	public void methodA(int k) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void methodC() {
		// TODO Auto-generated method stub
		
	}
	
}