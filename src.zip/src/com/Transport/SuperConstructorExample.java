package com.Transport;

public class SuperConstructorExample {
	public static void main(String args[])
	{
    B1 b = new B1(10);
    B1 b2 = new B1();
	}
}
class A1
{
	A1(int i)
	{
		System.out.println("No arg constructor");
	}
	
	
	
}
class B1 extends A1
{
	B1()
	{
		super(10);
	}
	B1(int i)
	{
		super(i);
	}
}
