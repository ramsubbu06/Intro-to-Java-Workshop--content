package com.Transport;

public class Fruit {
	public static void main(String args[])
	{
		
	}
	public static String getBanana()
	{
		getPineapple();
		return "Here is a Banana..";
		
	}
	public static String getPineapple()
	{
		getBanana();
		Fruit f = new Fruit();
		f.getWalnut();
		return ("Here is a Pineapple..");
	}
	public String getWalnut()
	{
		getPineapple();
		getBanana();
		return("Here is a walnut");
	}
	
}
