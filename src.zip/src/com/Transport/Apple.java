package com.Transport;

public class Apple {
	public int y = 0;
	
		public static void main(String args[])
		{
		Apple a = new Apple();
		Apple b = new Apple();
		System.out.println("--------Non Static variable--------");
		System.out.println(b.y);//0
		a.y = 5;
		System.out.println(b.y);//0
		a.y = 10;
		System.out.println(a.y);//10
	    
     }
	}

