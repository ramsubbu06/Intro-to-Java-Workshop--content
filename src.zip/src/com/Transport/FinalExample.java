package com.Transport;

public class FinalExample {

}

final class Base {
	  final int i=5;
	  final void foo() {
	//  i=10; 
	//what will the compiler say about this?
	  }
	}

/*class Derived extends Base { // Error 
	  // another foo ...
	  void foo() {
	    
	  }
	}*/

