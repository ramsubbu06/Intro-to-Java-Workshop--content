package com.Transport;

//import java.time.LocalDate;


public class PackageExample {

	public static void main(String args[])
	{
		java.time.LocalDate d1 = java.time.LocalDate.now();
	}
}
