package com.Transport;

public class OverloadingExample {
	
	public String MethodA(int a)
	{
		return("Method with a single argument");
	}
	public String MethodA(int a,int b)
	{
		return("Method with a two arguments");
	}
	public static void main(String args[])
	{
		
	}

}
