package com.Transport;

public abstract class Shape {
	public String BackGroundColor="black";
	public String ForeGroundColor="White";
	public abstract void draw(); 
	public void setColor(String color)
	{System.out.println("The background color is "+color);}
	public void move(int x, int y) {
	 setColor(BackGroundColor);
         draw();
         setColor(ForeGroundColor);
         draw();
       }
	}
class Circle extends Shape {
	public void draw() {
        // draw the circle ...
      }
}
