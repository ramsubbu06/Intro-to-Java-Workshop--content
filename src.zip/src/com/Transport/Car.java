package com.Transport;
public class Car {
	public String color ;
	public String name;
	public String make;
	
	public static void main(String args[])
	{
		Car C = new Car();
		C.color="black";
		C.name="benz";
		C.drivingBackward();
		
		
	}
	public void drivingForward()
	{
		//Write your Business Logic here
	   System.out.println("whee..I am going forward");
	}
	public void drivingBackward()
	{
		//Write your Business Logic here
	   System.out.println("Oops..I am going backward");
	}
	public void cruising()
	{
		//Write your Business Logic here
	   System.out.println("coool..");
	}

}
