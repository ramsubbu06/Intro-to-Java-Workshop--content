package com.Transport;

import java.util.ArrayList;
import java.util.function.Predicate;

public class LambdaExample {

	public static void main(String args[])
	{
		//Lambdagreet = ()-> System.out.println("hello");
		 FunctionalInterfaceEx Lambdagreet = ()-> System.out.println("Hello folks");
		 Lambdagreet.greet();
		 
		 //removeif//
		 ArrayList<String> li = new ArrayList();
		 li.add("Niagara");
		 li.add("Yellowstone");
		 li.add("Yosemite");
		 li.add("Dry Tortugas");
		 li.add("Everglades");
		 System.out.println(li);
		 li.removeIf(s->s.charAt(0) =='Y');
		 System.out.println(li);
	}
}



interface FunctionalInterfaceEx {

	void greet();
}
