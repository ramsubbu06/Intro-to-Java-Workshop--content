package com.Transport;

public abstract class AbstractExample {
	public abstract void method1();

}

class SuperClass
{
	void method1()
	{
		
	}
}
	class SubClass
	{
	
	
}
