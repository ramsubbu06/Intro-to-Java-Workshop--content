package com.Transport;

public class PassByValueExample {
	int y= 999;

	
	public static void main(String args[])
	{
		int x=100;
		
		int intArray[]={1,2,3,4};
		PassByValueExample p1 = new PassByValueExample();
		System.out.println("--Before the call--");
		System.out.println("the value of x--"+x);
		System.out.println("the value of p1.y--"+p1.y);
		System.out.println("the value of intArray"+intArray[0]);
		System.out.println("After the change call---");
		p1.change(x, p1, intArray);
		System.out.println("the value of x--"+x);
		System.out.println("the value of p1.y--"+p1.y);
		System.out.println("the value of intArray"+intArray[0]);
		PassByValueExample p5 = new PassByValueExample();
		System.out.println("--Before foo--");
		System.out.println("p5.y--"+p5.y);
		System.out.println("--After foo--");
		p1.foo(p5);
		System.out.println("p5.y--"+p5.y);
		
	}
	public void change(int x,PassByValueExample p1,int intArray[])
	{
		x=200;
		intArray[0]=1000;
		y=2000;
		
	}
	public void foo(PassByValueExample p5)
	{
		//p5= new PassByValueExample();
		p5.y=8989;
	}
}
